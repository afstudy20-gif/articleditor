(() => {
  const m = scrape();
  return m;

  function scrape() {
    const meta = {
      type: "webpage",
      title: null,
      authors: [],
      issued: null,
      containerTitle: null,
      publisher: null,
      siteName: null,
      doi: null,
      isbn: null,
      pmid: null,
      arxivId: null,
      url: location.href,
      accessed: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() },
      lang: document.documentElement.lang || null,
      pageNumber: null,
      volume: null,
      issue: null,
      abstract: null
    };

    const get = (sel, attr = "content") => document.querySelector(sel)?.getAttribute(attr) || null;
    const getAll = (sel, attr = "content") => [...document.querySelectorAll(sel)].map((el) => el.getAttribute(attr)).filter(Boolean);

    const citTitle = get('meta[name="citation_title"]');
    const ogTitle = get('meta[property="og:title"]');
    const dcTitle = get('meta[name="DC.title"]') || get('meta[name="dc.title"]');
    const siteName = get('meta[property="og:site_name"]') || null;
    meta.title = cleanTitle(citTitle || dcTitle || ogTitle || document.title || null, siteName);

    const citAuthors = getAll('meta[name="citation_author"]');
    const dcAuthors = getAll('meta[name="DC.creator"]').concat(getAll('meta[name="dc.creator"]'));
    const articleAuthors = getAll('meta[property="article:author"]').concat(getAll('meta[name="author"]'));
    const rawAuthors = (citAuthors.length ? citAuthors : dcAuthors.length ? dcAuthors : articleAuthors);
    meta.authors = rawAuthors.map(parseAuthor);

    const citDate = get('meta[name="citation_publication_date"]') || get('meta[name="citation_date"]') || get('meta[name="citation_online_date"]') || get('meta[name="prism.publicationDate"]');
    const dcDate = get('meta[name="DC.date"]') || get('meta[name="dc.date"]') || get('meta[name="DC.date.issued"]');
    const ogDate = get('meta[property="article:published_time"]') || get('meta[name="date"]') || get('meta[name="pubdate"]') || get('meta[itemprop="datePublished"]');
    const timeEl = document.querySelector("time[datetime]")?.getAttribute("datetime") || document.querySelector("time[pubdate]")?.getAttribute("datetime");
    meta.issued = parseDate(citDate || dcDate || ogDate || timeEl);

    meta.containerTitle = get('meta[name="citation_journal_title"]') || get('meta[name="prism.publicationName"]') || null;
    meta.publisher = get('meta[name="citation_publisher"]') || get('meta[name="DC.publisher"]') || null;
    meta.siteName = get('meta[property="og:site_name"]') || null;
    meta.volume = get('meta[name="citation_volume"]');
    meta.issue = get('meta[name="citation_issue"]');
    const firstPage = get('meta[name="citation_firstpage"]');
    const lastPage = get('meta[name="citation_lastpage"]');
    if (firstPage) meta.pageNumber = lastPage ? `${firstPage}-${lastPage}` : firstPage;
    meta.abstract = get('meta[name="citation_abstract"]') || get('meta[name="description"]') || get('meta[property="og:description"]');

    meta.doi = extractDoi();
    meta.isbn = get('meta[name="citation_isbn"]') || extractIsbn();
    meta.pmid = get('meta[name="citation_pmid"]') || extractPmid();
    meta.arxivId = get('meta[name="citation_arxiv_id"]') || extractArxiv();

    const jsonLd = readJsonLd();
    if (jsonLd) mergeJsonLd(meta, jsonLd);

    if (meta.doi || meta.containerTitle) meta.type = "article-journal";
    else if (meta.isbn) meta.type = "book";
    else if (meta.arxivId) meta.type = "article";

    return meta;
  }

  function cleanTitle(t, site) {
    if (!t) return null;
    let s = String(t).trim();
    // Strip trailing site suffix: " | Site", " - Site", " — Site"
    const sep = /[|\-–—·•:]\s+[^|\-–—·•:]+$/;
    if (site) {
      const escSite = site.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      const re = new RegExp(`\\s*[|\\-–—·•:]\\s*${escSite}\\s*$`, "i");
      s = s.replace(re, "");
    } else if (sep.test(s) && s.length > 40) {
      // long titles with separator: drop trailing segment if it looks like site
      s = s.replace(sep, "");
    }
    return s.trim();
  }

  function parseAuthor(raw) {
    if (!raw) return null;
    raw = raw.trim();
    if (raw.includes(",")) {
      const [family, given] = raw.split(",", 2).map((s) => s.trim());
      return { family, given };
    }
    const parts = raw.split(/\s+/);
    if (parts.length === 1) return { literal: parts[0] };
    return { given: parts.slice(0, -1).join(" "), family: parts.at(-1) };
  }

  function parseDate(s) {
    if (!s) return null;
    const m = String(s).match(/(\d{4})(?:[-\/](\d{1,2}))?(?:[-\/](\d{1,2}))?/);
    if (!m) return null;
    return {
      year: parseInt(m[1], 10),
      month: m[2] ? parseInt(m[2], 10) : null,
      day: m[3] ? parseInt(m[3], 10) : null
    };
  }

  function extractDoi() {
    const meta = document.querySelector('meta[name="citation_doi"], meta[name="DC.identifier.doi"], meta[scheme="doi"]')?.content;
    if (meta) return cleanDoi(meta);
    const m = (location.href + " " + document.body.innerText.slice(0, 5000)).match(/10\.\d{4,9}\/[^\s"<>]+/);
    return m ? cleanDoi(m[0]) : null;
  }
  function cleanDoi(d) { return d.replace(/^(https?:\/\/)?(dx\.)?doi\.org\//i, "").replace(/[.,;]+$/, ""); }

  function extractIsbn() {
    const m = document.body.innerText.match(/\b97[89][-\s]?\d{1,5}[-\s]?\d{1,7}[-\s]?\d{1,7}[-\s]?\d\b/);
    return m ? m[0].replace(/[-\s]/g, "") : null;
  }

  function extractPmid() {
    const u = location.href.match(/pubmed\.ncbi\.nlm\.nih\.gov\/(\d+)/);
    return u ? u[1] : null;
  }

  function extractArxiv() {
    const u = location.href.match(/arxiv\.org\/(?:abs|pdf)\/([^\s\/?#]+)/);
    return u ? u[1].replace(/\.pdf$/, "") : null;
  }

  function readJsonLd() {
    for (const el of document.querySelectorAll('script[type="application/ld+json"]')) {
      try {
        const data = JSON.parse(el.textContent);
        const arr = Array.isArray(data) ? data : [data];
        for (const d of arr) {
          const t = d["@type"];
          if (t && /Article|ScholarlyArticle|NewsArticle|BlogPosting|Book|WebPage/.test(String(t))) return d;
        }
      } catch {}
    }
    return null;
  }

  function mergeJsonLd(meta, d) {
    if (!meta.title && d.headline) meta.title = d.headline;
    if (!meta.title && d.name) meta.title = d.name;
    if (!meta.authors.length && d.author) {
      const arr = Array.isArray(d.author) ? d.author : [d.author];
      meta.authors = arr.map((a) => (typeof a === "string" ? parseAuthor(a) : parseAuthor(a.name))).filter(Boolean);
    }
    if (!meta.issued && (d.datePublished || d.dateCreated)) meta.issued = parseDate(d.datePublished || d.dateCreated);
    if (!meta.publisher && d.publisher) meta.publisher = typeof d.publisher === "string" ? d.publisher : d.publisher.name;
    if (!meta.containerTitle && d.isPartOf?.name) meta.containerTitle = d.isPartOf.name;
  }

  // --- IN-TEXT CITATIONS LINKER & POPUPS (HTML) ---
  
  if (!window.__refdownLinked) {
    window.__refdownLinked = true;
    // Delay slightly to let lazy resources load
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", initLinker);
    } else {
      initLinker();
    }
  }

  function initLinker() {
    try {
      const refMap = findReferences();
      if (refMap && refMap.size > 0) {
        linkCitations(refMap);
      }
    } catch (e) {
      console.warn("[refdown] citation linking error:", e);
    }
  }

  function findReferences() {
    const refMap = new Map();
    const headings = [...document.querySelectorAll('h1, h2, h3, h4, h5, h6, p, div, strong, span')];
    let refHeading = null;
    const keywords = [/references/i, /kaynakça/i, /bibliography/i, /sources/i, /kaynaklar/i];
    for (const h of headings) {
      const txt = h.textContent.trim();
      if (txt.length < 30 && keywords.some(rx => rx.test(txt))) {
        refHeading = h;
      }
    }
    
    if (!refHeading) {
      const refElements = document.querySelectorAll('li[class*="reference"], li[class*="ref-item"], p[class*="reference"], div[class*="reference"]');
      if (refElements.length > 0) {
        refElements.forEach((el, index) => {
          const num = index + 1;
          refMap.set(num.toString(), el.textContent.trim());
          refMap.set(`[${num}]`, el.textContent.trim());
        });
      }
      return refMap;
    }
    
    let container = refHeading.nextElementSibling;
    if (!container) {
      container = refHeading.parentElement?.nextElementSibling;
    }
    
    if (container) {
      const listItems = container.querySelectorAll('li');
      if (listItems.length > 0) {
        listItems.forEach((li, index) => {
          const num = index + 1;
          refMap.set(num.toString(), li.textContent.trim());
          refMap.set(`[${num}]`, li.textContent.trim());
        });
      } else {
        const items = container.querySelectorAll('p, div');
        let seq = 1;
        items.forEach((item) => {
          const txt = item.textContent.trim();
          if (!txt) return;
          const match = /^\s*\[?(\d+)\]?[\.\:\s\-–—]*/.exec(txt);
          if (match) {
            const num = match[1];
            refMap.set(num, txt);
            refMap.set(`[${num}]`, txt);
          } else if (txt.length > 30) {
            refMap.set(seq.toString(), txt);
            refMap.set(`[${seq}]`, txt);
            seq++;
          }
        });
      }
    }
    
    return refMap;
  }
  
  function linkCitations(refMap) {
    const walk = document.createTreeWalker(
      document.body,
      NodeFilter.SHOW_TEXT,
      {
        acceptNode: (node) => {
          const parent = node.parentElement;
          if (!parent) return NodeFilter.FILTER_REJECT;
          const tag = parent.tagName.toLowerCase();
          if (tag === 'script' || tag === 'style' || tag === 'textarea' || tag === 'input' || parent.isContentEditable) {
            return NodeFilter.FILTER_REJECT;
          }
          if (tag === 'a' || parent.closest('a') || parent.closest('h1, h2, h3, h4, h5, h6')) {
            return NodeFilter.FILTER_REJECT;
          }
          if (parent.closest('.references, #references, .bibliography, #bibliography, .reflist')) {
            return NodeFilter.FILTER_REJECT;
          }
          return NodeFilter.FILTER_ACCEPT;
        }
      }
    );
    
    const nodes = [];
    let node;
    while (node = walk.nextNode()) {
      nodes.push(node);
    }
    
    const regex = /\[(\d+)(?:\s*([,\-–—])\s*(\d+))?\]/g;
    
    nodes.forEach((textNode) => {
      const text = textNode.textContent;
      if (!text || !text.includes('[')) return;
      
      let match;
      let lastIndex = 0;
      const fragments = [];
      let hasMatch = false;
      
      regex.lastIndex = 0;
      while ((match = regex.exec(text)) !== null) {
        hasMatch = true;
        const index = match.index;
        
        if (index > lastIndex) {
          fragments.push(document.createTextNode(text.slice(lastIndex, index)));
        }
        
        const num1 = parseInt(match[1], 10);
        const sep = match[2];
        const num2 = match[3] ? parseInt(match[3], 10) : null;
        
        const span = document.createElement('span');
        span.className = 'refdown-citation-container';
        span.style.position = 'relative';
        span.style.display = 'inline';
        
        if (num2 && sep === '-') {
          for (let i = num1; i <= num2; i++) {
            if (i > num1) span.appendChild(document.createTextNode(', '));
            span.appendChild(createCitationLink(i.toString(), refMap));
          }
        } else if (num2 && sep === ',') {
          span.appendChild(createCitationLink(num1.toString(), refMap));
          span.appendChild(document.createTextNode(', '));
          span.appendChild(createCitationLink(num2.toString(), refMap));
        } else {
          span.appendChild(createCitationLink(match[1], refMap));
        }
        
        fragments.push(span);
        lastIndex = regex.lastIndex;
      }
      
      if (hasMatch) {
        if (lastIndex < text.length) {
          fragments.push(document.createTextNode(text.slice(lastIndex)));
        }
        
        const parent = textNode.parentElement;
        if (parent) {
          const nextSibling = textNode.nextSibling;
          fragments.forEach((frag) => {
            parent.insertBefore(frag, nextSibling);
          });
          parent.removeChild(textNode);
        }
      }
    });
  }
  
  function createCitationLink(numStr, refMap) {
    const a = document.createElement('a');
    a.href = '#';
    a.className = 'refdown-citation-link';
    a.textContent = `[${numStr}]`;
    a.style.color = '#2b6cb0';
    a.style.textDecoration = 'none';
    a.style.fontWeight = 'bold';
    a.style.cursor = 'pointer';
    
    const refText = refMap.get(numStr) || refMap.get(`[${numStr}]`) || 'Reference details not found on page.';
    
    a.addEventListener('mouseenter', () => showTooltip(a, refText));
    a.addEventListener('mouseleave', () => hideTooltip());
    a.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      scrollToReference(numStr);
    });
    
    return a;
  }
  
  let activeTooltip = null;
  
  function showTooltip(anchor, text) {
    hideTooltip();
    
    const tooltip = document.createElement('div');
    tooltip.className = 'refdown-citation-tooltip';
    tooltip.textContent = text;
    
    tooltip.style.position = 'fixed';
    tooltip.style.zIndex = '999999';
    tooltip.style.backgroundColor = '#1a202c';
    tooltip.style.color = '#fff';
    tooltip.style.padding = '8px 12px';
    tooltip.style.borderRadius = '6px';
    tooltip.style.fontSize = '12px';
    tooltip.style.lineHeight = '1.4';
    tooltip.style.maxWidth = '300px';
    tooltip.style.boxShadow = '0 4px 6px -1px rgba(0,0,0,0.1), 0 2px 4px -1px rgba(0,0,0,0.06)';
    tooltip.style.pointerEvents = 'none';
    tooltip.style.transition = 'opacity 0.2s';
    tooltip.style.opacity = '0';
    
    document.body.appendChild(tooltip);
    
    const rect = anchor.getBoundingClientRect();
    const tooltipRect = tooltip.getBoundingClientRect();
    
    let top = rect.top - tooltipRect.height - 8;
    let left = rect.left + (rect.width - tooltipRect.width) / 2;
    
    if (top < 8) {
      top = rect.bottom + 8;
    }
    if (left < 8) {
      left = 8;
    }
    if (left + tooltipRect.width > window.innerWidth - 8) {
      left = window.innerWidth - tooltipRect.width - 8;
    }
    
    tooltip.style.top = `${top}px`;
    tooltip.style.left = `${left}px`;
    
    requestAnimationFrame(() => {
      tooltip.style.opacity = '1';
    });
    
    activeTooltip = tooltip;
  }
  
  function hideTooltip() {
    if (activeTooltip) {
      activeTooltip.remove();
      activeTooltip = null;
    }
  }
  
  function scrollToReference(numStr) {
    const elements = [...document.querySelectorAll('li, p, div')];
    for (const el of elements) {
      const text = el.textContent.trim();
      const startsWithPrefix = new RegExp(`^\\s*\\[?${numStr}\\]?[\\.\\:\\s\\-–—]`, 'i').test(text);
      if (startsWithPrefix) {
        el.scrollIntoView({ behavior: 'smooth', block: 'center' });
        const origBg = el.style.backgroundColor;
        el.style.backgroundColor = 'rgba(43, 108, 176, 0.2)';
        setTimeout(() => {
          el.style.backgroundColor = origBg;
        }, 2000);
        break;
      }
    }
  }
})();
